﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class searchWithCondition : ControllerBase
    {
        private readonly IService<Category, int> catServ;
        private readonly IService<Product, int> productServ;
        public searchWithCondition(IService<Category, int> catServ, IService<Product, int> productServ)
        {
            this.catServ = catServ;
            this.productServ = productServ;
        }
        [HttpGet("{Operator}")]
        public IActionResult Search(string CategoryNAme, string ProductName, string Operator)
        {
            //List<Product> pro = new List<Product>();
            if (ModelState.IsValid)
            {
                if (Operator == "&&")
                {
                    var catID = catServ.GetAsync().Result.Where(x => x.CategoryName == CategoryNAme).Select(x => x.CategoryRowId).FirstOrDefault();
                    if (catID != 0)
                    {
                        var catResultant = catServ.GetAsync(catID).Result;
                        var proExistance = productServ.GetAsync().Result.Where(x => x.CategoryRowId == catID);
                        var product = proExistance.Where(x => x.ProductName.ToLower() == ProductName.ToLower());
                        CatProd categoryProduct = new CatProd()
                        {
                            CategoryRowId = catID,
                            CategoryName = catResultant.CategoryName,
                            BasePrice = catResultant.BasePrice,
                        };
                        categoryProduct.Products = new List<Product>();
                        foreach (Product p in product)
                        {
                            categoryProduct.Products.Add(new Product() { CategoryRowId = p.CategoryRowId, ProductName = p.ProductName, ProductId = p.ProductId });
                        }
                        return Ok(categoryProduct);
                    }
                    else
                    {
                        return BadRequest("Oh Oh!No Such Catagory!");
                    }
                }
                else
                {
                    return BadRequest("Oh Oh!Invalid Operator!");
                }
            }
            return BadRequest("Oh Oh!");
        }
    }
}